from django.urls import path
from . import views
from . import auth_views, post_views, reel_views, profile_views, search_views

app_name = 'social_app'

urlpatterns = [
    # Main views
    path('', views.index, name='index'),
    path('users-who-liked-reels/', views.users_who_liked_reels, name='users_who_liked_reels'),
    path('users-who-commented-on-posts/', views.users_who_commented_on_posts, name='users_who_commented_on_posts'),
    path('following-relationships/', views.following_relationships, name='following_relationships'),
    path('user-comments-on-reels/', views.user_comments_on_reels, name='user_comments_on_reels'),
    path('user-comments-on-reels/<int:user_id>/', views.user_comments_on_reels, name='user_comments_on_reels_by_user'),
    
    # Authentication
    path('signup/', auth_views.signup_view, name='signup'),
    path('login/', auth_views.login_view, name='login'),
    path('logout/', auth_views.logout_view, name='logout'),
    
    # Posts
    path('post/create/', post_views.create_post, name='create_post'),
    path('post/<int:post_id>/', post_views.post_detail, name='post_detail'),
    path('post/<int:post_id>/like/', post_views.like_post, name='like_post'),
    path('post/<int:post_id>/delete/', post_views.delete_post, name='delete_post'),
    
    # Reels
    path('reel/create/', reel_views.create_reel, name='create_reel'),
    path('reel/<int:reel_id>/', reel_views.reel_detail, name='reel_detail'),
    path('reel/<int:reel_id>/like/', reel_views.like_reel, name='like_reel'),
    path('reel/<int:reel_id>/delete/', reel_views.delete_reel, name='delete_reel'),
    
    # User profiles
    path('profile/<str:username>/', profile_views.user_profile, name='user_profile'),
    path('profile/<str:username>/follow/', profile_views.follow_user, name='follow_user'),
    path('profile/edit/', profile_views.edit_profile, name='edit_profile'),
    path('profile/<str:username>/followers/', profile_views.followers_list, name='followers_list'),
    path('profile/<str:username>/following/', profile_views.following_list, name='following_list'),
    
    # Search
    path('search/', search_views.search, name='search'),
]
